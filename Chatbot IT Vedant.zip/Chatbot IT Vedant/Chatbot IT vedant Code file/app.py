
from flask import Flask, render_template, request
from chatterbot import ChatBot
from chatterbot.trainers import ChatterBotCorpusTrainer
from chatterbot.trainers import ListTrainer

app = Flask(__name__)

bott = ChatBot("Ajinkya's ITVT ChatBot")
trainer2 = ListTrainer(bott)
trainer2.train([    "Hey",
    "Hi, How may i help you",
    "Hi",
    "Hi, How may i help you",
    "How are you doing?",
    "I'm doing great.",
    "That is good to hear",
    "Thank you.",
    "You're welcome.",
    "What is your name?", "My name is ITVT ChatBot",
    "Who created you?", "Ajinkya from IT vedant",
    "Tell me about yourself","I am ITVT, Alexa's brother",
    "I am looking for job", "Great!, You have already completed the first step towards it, for more details you can call us or whatsup us on this no. XXXXX",
    "I need a guidance for courses","Tell me which course you are looking for,1. Full stack developer, Data science",
    "Full stack developer"," Great!, We provide offline as well as online courses,our expert will definately guide you, please contact on this no. XXXXX",
    "Data science"," Great!, We provide offline as well as online courses,our expert will definately guide you, please contact on this no. XXXXX",
    "How to take admission?","You can visit our nearest branch where our career guides will guide you ",
    "Can i take lectures in hybrid","Yes the hybrid mode is eligible for students who have enrolled themselves for offline lectures",
    "can i pay fees in EMI's","Yes, students can avail of No Cost EMI’s (No Interest EMI’s) at Itvedant",
    "When can I expect to receive placement calls and how long ?","We are equipped with a strong Placement Cell Team who make sure that our students are placed well.",
    "Bye","Bye, have nice day",
    "How are you","I don't have feeling, I am machine thank you for asking",
    "What i will learn in data science course",
    "This is really good question, You will learn: 1.How self driving car can read the sign board and traffic signal using OCR and OpenCV. 2 How google translate the language using NLP. 3 the chatbot with you are chatting is also created by one of the student of IT vedant and lot more things are there",
    "Why don't you provide 'pay after you get salary scheme'?","There are some institute which provide this scheme but there you have to pay security deposit which is nothing but fees",
    ])
trainer = ChatterBotCorpusTrainer(bott)
trainer.train("chatterbot.corpus.english")
#trainer2.train(["Thank You","Welcome"])

@app.route("/")
def home(): 
	return render_template("home.html")

@app.route("/get")
def get_bot_response():
	userText = request.args.get('msg')
	return str(bott.get_response(userText))
if __name__ == "__main__":
	app.run()