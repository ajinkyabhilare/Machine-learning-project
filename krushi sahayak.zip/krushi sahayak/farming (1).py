import mysql.connector
mycon=mysql.connector.connect(host="localhost",user="root",password="")
print(mycon)
cur=mycon.cursor()
print(cur)
choice=int(input("Enter 1 for registration,2 for croping details,3 for search :"))
mycon.database="ajinkya"
if choice==1:
    Customerid=input("Enter customer id :")
    name=input("Enter your name :")
    addressdist=input("Enter your address district :")
    addresstaluka=input("Enter your address taluka :")
    mobileno=int(input("Enter your mobile number :"))
    sql="insert into registration (Customerid,name,addressdist,addresstaluka,mobileno) values (%s,%s,%s,%s,%s)"
    val=(Customerid,name,addressdist,addresstaluka,mobileno)
    cur.execute(sql,val)
    mycon.commit()
    print("data inserted")
elif choice==2:
    cropname=input("Enter the crop name :")
    date=input("Enter date :")
    harvestingdate=input("Enter harvesting date :")
    farmarea=input("Enter the sowing area :")
    production=input("Enter expected production :")
    sql="insert into cropping_details(cropname,date,harvestingdate,farmarea,production) values(%s,%s,%s,%s,%s)"
    val=(cropname,date,harvestingdate,farmarea,production)
    cur.execute(sql,val)
    mycon.commit()
    print("data inserted")
else:
    cur.execute("SELECT * FROM cropping_details")
    result=cur.fetchall()
    print(result)
    from datetime import date
    c=input("enter name of crop :")
    if c=="onion":
        cur.execute("SELECT sum(production) FROM cropping_details where cropname='onion'")
        summ=cur.fetchall()
        print("total production :",summ)
    elif c=="potato":
        cur.execute("SELECT sum(production) FROM cropping_details where cropname='potato'")
        summ=cur.fetchall()
        print("total production :",summ)
    else:
        print("not matching")



