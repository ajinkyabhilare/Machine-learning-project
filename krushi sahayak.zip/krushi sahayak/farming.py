import mysql.connector
mycon=mysql.connector.connect(host="localhost",user="root",password="")
print(mycon)
cur=mycon.cursor()
print(cur)
while True:
    choice=int(input("Enter 1 for registration\n 2 for croping details\n 3 for search :\n 4 for Exit:"))
    mycon.database="ajinkya"

    if choice==1:
        id=input("Enter customer id :")
        name=input("Enter your name :")
        address=input("Enter your address district :")
    
        sql="insert into farmer (id,name,address) values (%s,%s,%s)"
        val=(id,name,address)
        cur.execute(sql,val)
        mycon.commit()
        print("data inserted")
    elif choice==2:
        id=input("Enter customer id :")
        crop_name=input("Enter the crop name :")
        Sowing_date=input("Enter date :")
        Harvesting_date=input("Enter harvesting date :")
        Area_Acre=input("Enter the sowing area :")
        Exp_production=input("Enter expected production :")
        sql="insert into cropping_details(id,crop_name,Sowing_date,Harvesting_date,Area_Acre,Exp_production) values(%s,%s,%s,%s,%s,%s)"
        val=(id,crop_name,Sowing_date,Harvesting_date,Area_Acre,Exp_production)
        cur.execute(sql,val)
        mycon.commit()
        print("data inserted")
    elif choice==3:    
    
        from datetime import date
        c=input("enter name of crop :")
        if c=="onion":
            cur.execute("SELECT sum(Exp_production) as Production, address,Harvesting_date,crop_name from farmer F inner join cropping_details C on F.id=C.id group by address")
            summ=cur.fetchall()
            print("total production :",summ)

        else:
            print("not matching")

    elif choice==4:
        break



