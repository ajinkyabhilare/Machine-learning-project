-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 28, 2023 at 09:43 AM
-- Server version: 10.4.21-MariaDB
-- PHP Version: 8.0.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `ajinkya`
--

-- --------------------------------------------------------

--
-- Table structure for table `cropping_details`
--

CREATE TABLE `cropping_details` (
  `id` int(20) DEFAULT NULL,
  `crop_name` varchar(25) DEFAULT NULL,
  `Sowing_date` date DEFAULT NULL,
  `Harvesting_date` date DEFAULT NULL,
  `Area_Acre` int(20) DEFAULT NULL,
  `Exp_production` int(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `cropping_details`
--

INSERT INTO `cropping_details` (`id`, `crop_name`, `Sowing_date`, `Harvesting_date`, `Area_Acre`, `Exp_production`) VALUES
(1, 'onion', '2023-07-01', '2023-10-01', 3, 10),
(2, 'onion', '2023-07-01', '2023-10-01', 4, 12),
(3, 'onion', '2023-07-01', '2023-10-01', 7, 20),
(4, 'onion', '2023-07-01', '2023-10-01', 1, 2),
(5, 'onion', '2023-07-01', '2023-10-01', 2, 3),
(6, 'onion', '2023-07-01', '2023-10-01', 1, 2),
(7, 'onion', '2023-07-01', '2023-10-01', 1, 2),
(8, 'onion', '2023-07-01', '2023-10-01', 3, 30),
(9, 'onion', '2023-07-01', '2023-10-01', 3, 40),
(10, 'onion', '2023-07-01', '2023-10-01', 4, 30),
(11, 'onion', '2023-07-01', '2023-10-01', 2, 20),
(12, 'onion', '2023-07-01', '2023-10-01', 1, 2),
(13, 'onion', '2023-07-01', '2023-10-01', 1, 1),
(14, 'onion', '2023-07-01', '2023-10-01', 3, 3),
(15, 'onion', '2023-07-01', '2023-10-01', 2, 2),
(16, 'onion', '2023-07-01', '2023-10-01', 5, 10),
(17, 'onion', '2023-07-01', '2023-10-01', 4, 10);

-- --------------------------------------------------------

--
-- Table structure for table `farmer`
--

CREATE TABLE `farmer` (
  `id` int(20) NOT NULL,
  `name` varchar(25) DEFAULT NULL,
  `address` varchar(25) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `farmer`
--

INSERT INTO `farmer` (`id`, `name`, `address`) VALUES
(1, 'Ajinkya', 'Pune'),
(2, 'Sahil', 'Pune'),
(3, 'Prem', 'Pune'),
(4, 'santosh', 'Nashik'),
(5, 'Rohan', 'Nashik'),
(6, 'sandesh', 'Nashik'),
(7, 'Vihaan', 'Nashik'),
(8, 'Sameer', 'Kolhapur'),
(9, 'Santosh', 'kolhapur'),
(10, 'sandesh', 'kolhapur'),
(11, 'anmol', 'kolhapur'),
(12, 'amit', 'satara'),
(13, 'Devendra', 'satara'),
(14, 'Adity', 'Satara'),
(15, 'Adesh', 'satara'),
(16, 'mangesh', 'Pune'),
(17, 'onion', 'Pune');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `cropping_details`
--
ALTER TABLE `cropping_details`
  ADD KEY `id` (`id`);

--
-- Indexes for table `farmer`
--
ALTER TABLE `farmer`
  ADD PRIMARY KEY (`id`);

--
-- Constraints for dumped tables
--

--
-- Constraints for table `cropping_details`
--
ALTER TABLE `cropping_details`
  ADD CONSTRAINT `cropping_details_ibfk_1` FOREIGN KEY (`id`) REFERENCES `farmer` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
